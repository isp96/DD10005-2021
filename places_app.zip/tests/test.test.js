describe("Testing the Jest environmnet", () => {
    it("tests ouer testing framework if it works", () => {
        expect(2).toBe(2)        
    });
});